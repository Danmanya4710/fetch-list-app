import React, { useEffect, useState } from 'react'
import ListComponent from './components/ListComponent'

const App = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((response) => {
        if (!response.ok) throw new Error('Network response was not ok')
        return response.json()
      })
      .then((data) => setUsers(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <p>Loading...</p>
  if (error) return <p>Error: {error}</p>
  if (users.length === 0) return <p>No users found.</p>

  return (
    <div>
      <h1>User List</h1>
      <ListComponent items={users} renderItem={(user) => (
        <li key={user.id}>
          <strong>{user.name}</strong> - {user.email}
        </li>
      )} />
    </div>
  )
}

export default App