# Fetch and Display List from an API

This is a mini React project that fetches data from an API and displays it in a reusable list component.

## Features

- Fetch data using `useEffect`
- Store and manage data using `useState`
- Reusable `ListComponent` for rendering items dynamically
- Semantic HTML
- Handles loading, error, and empty states

## To Run Locally

```bash
npm install
npm run dev
```